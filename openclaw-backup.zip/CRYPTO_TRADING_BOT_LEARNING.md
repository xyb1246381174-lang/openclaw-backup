# 加密货币交易机器人学习笔记

> 学习日期：2026-02-08
> 学习目标：了解交易机器人架构、策略、风险管理

---

## 📋 目录

1. [交易机器人类型](#交易机器人类型)
2. [核心架构](#核心架构)
3. [常见策略](#常见策略)
4. [风险管理](#风险管理)
5. [技术栈](#技术栈)
6. [著名项目](#著名项目)
7. [学习路线](#学习路线)

---

## 🤖 交易机器人类型

### 1. 套利机器人 (Arbitrage Bot)
- **原理**：利用不同交易所价格差获利
- **例子**：
  - Binance vs Coinbase 价格差
  - 跨链套利
- **风险**：
  - 执行延迟
  - 交易费用
  - 网络拥堵

### 2. 趋势跟随机器人 (Trend Following)
- **原理**：跟随市场趋势，低买高卖
- **策略**：
  - 移动平均线交叉
  - 突破交易
  - 动量指标
- **风险**：
  - 假突破
  - 趋势反转

### 3. 做市机器人 (Market Making)
- **原理**：提供流动性，赚取买卖价差
- **策略**：
  - 限价单两边挂单
  - 捕捉波动
- **风险**：
  - 单边行情亏损
  - 库存风险

### 4. 信号机器人 (Signal Bot)
- **原理**：产生交易信号，通知用户
- **策略**：
  - 技术指标信号
  - 链上数据分析
  - 社交媒体情绪
- **风险**：
  - 信号延迟
  - 误判

### 5. AI/ML 机器人
- **原理**：机器学习预测价格
- **策略**：
  - LSTM 预测
  - 强化学习
  - 情感分析
- **风险**：
  - 过拟合
  - 数据质量

---

## 🏗️ 核心架构

### 典型交易机器人架构

```
┌─────────────────────────────────────────────────────────────┐
│                    交易机器人架构                             │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐     │
│  │   数据层    │    │   策略层    │    │   执行层    │     │
│  ├─────────────┤    ├─────────────┤    ├─────────────┤     │
│  │            │    │            │    │            │     │
│  │ • 价格数据  │───▶│ • 策略逻辑  │───▶│ • 订单管理  │     │
│  │ • 链上数据  │    │ • 信号生成  │    │ • 执行交易  │     │
│  │ • 新闻情绪  │    │ • 风险管理  │    │ • 仓位管理  │     │
│  │ • 社交媒体  │    │ • 回测验证  │    │ • 成交确认  │     │
│  │            │    │            │    │            │     │
│  └─────────────┘    └─────────────┘    └─────────────┘     │
│         │                  │                  │             │
│         └──────────────────┼──────────────────┘             │
│                            ▼                               │
│                   ┌─────────────┐                          │
│                   │   监控层    │                          │
│                   ├─────────────┤                          │
│                   │            │                          │
│                   │ • 性能监控  │                          │
│                   │ • 异常报警  │                          │
│                   │ • 日志记录  │                          │
│                   │ • 人工干预  │                          │
│                   │            │                          │
│                   └─────────────┘                          │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

### 核心组件

#### 1. 数据收集器 (Data Collector)
```python
# 数据源示例
data_sources = {
    "price": ["binance", "coinbase", "kraken"],
    "onchain": ["etherscan", "solscan", "dune"],
    "news": ["twitter", "reddit", "cryptopanic"],
    "social": ["telegram", "discord"]
}
```

#### 2. 策略引擎 (Strategy Engine)
```python
class StrategyEngine:
    def __init__(self):
        self.strategies = []
        self.signal_queue = Queue()
    
    def add_strategy(self, strategy):
        self.strategies.append(strategy)
    
    def run(self):
        for strategy in self.strategies:
            signal = strategy.analyze()
            if signal:
                self.signal_queue.put(signal)
```

#### 3. 订单管理器 (Order Manager)
```python
class OrderManager:
    def __init__(self, exchange):
        self.exchange = exchange
        self.orders = {}
    
    def create_order(self, signal):
        # 验证订单
        # 计算仓位
        # 设置止损止盈
        # 发送订单
    
    def monitor_orders(self):
        # 检查成交
        # 更新状态
        # 触发止损止盈
```

#### 4. 风险管理器 (Risk Manager)
```python
class RiskManager:
    def __init__(self):
        self.max_position = 0.1  # 最大仓位 10%
        self.max_loss = 0.02     # 单日最大亏损 2%
        self.stop_loss = 0.05    # 止损 5%
    
    def check_risk(self, signal):
        # 检查仓位
        # 检查亏损
        # 检查相关性
        return approved/rejected
```

---

## 📈 常见策略

### 1. 均线交叉策略
```python
def ma_crossover_strategy(prices, short_ma=20, long_ma=50):
    short = prices.rolling(short_ma).mean()
    long = prices.rolling(long_ma).mean()
    
    if short > long and short_prev <= long_prev:
        return "BUY"
    elif short < long and short_prev >= long_prev:
        return "SELL"
    return "HOLD"
```

### 2. RSI 超卖超买
```python
def rsi_strategy(prices, period=14, overbought=70, oversold=30):
    delta = prices.diff()
    gain = (delta.where(delta > 0, 0)).rolling(period).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(period).mean()
    rs = gain / loss
    rsi = 100 - (100 / (1 + rs))
    
    if rsi < oversold:
        return "BUY"
    elif rsi > overbought:
        return "SELL"
    return "HOLD"
```

### 3. 突破策略
```python
def breakout_strategy(prices, window=20):
    high = prices.rolling(window).max()
    low = prices.rolling(window).min()
    
    if prices > high:
        return "BUY"
    elif prices < low:
        return "SELL"
    return "HOLD"
```

### 4. 网格策略
```python
class GridStrategy:
    def __init__(self, price, grid_size, grid_count):
        self.grids = []
        self.create_grids(price, grid_size, grid_count)
    
    def create_grids(self, price, size, count):
        for i in range(-count, count + 1):
            self.grids.append({
                'price': price + i * size,
                'side': 'buy' if i < 0 else 'sell',
                'amount': 0.001,  # 每次下单量
                'filled': False
            })
```

---

## 🛡️ 风险管理

### 核心风控原则

```
┌────────────────────────────────────────┐
│           风险管理金字塔                 │
├────────────────────────────────────────┤
│                                        │
│           资金管理 (最底层)              │
│           • 总仓位限制                  │
│           • 单笔亏损限制                 │
│           • 每日亏损限制                 │
│                                        │
│           策略风控                      │
│           • 回测验证                    │
│           • 参数优化限制                 │
│           • 策略分散                    │
│                                        │
│           交易风控                      │
│           • 止损止盈                    │
│           • 仓位计算                    │
│           • 滑点控制                    │
│                                        │
│           系统风控                      │
│           • 网络监控                    │
│           • 异常检测                    │
│           • 紧急停止                    │
│                                        │
└────────────────────────────────────────┘
```

### 风控代码示例
```python
class RiskControl:
    def __init__(self, config):
        self.config = config
        self.daily_pnl = 0
        self.total_position = 0
        self.orders = []
    
    def can_trade(self, signal):
        # 检查日亏损限制
        if self.daily_pnl < -self.config.max_daily_loss:
            return False, "daily loss limit reached"
        
        # 检查总仓位
        if self.total_position >= self.config.max_position:
            return False, "position limit reached"
        
        # 检查订单频率
        if self.get_order_frequency() > self.config.max_orders_per_minute:
            return False, "order frequency limit"
        
        return True, "approved"
    
    def calculate_position(self, signal, price):
        # 凯利公式计算仓位
        kelly = (self.config.win_rate * signal.rr - (1 - self.config.win_rate)) / signal.rr
        position = self.config.balance * kelly * 0.5  # 半凯利
        
        # 限制最大仓位
        position = min(position, self.config.max_position * self.config.balance)
        
        return position
```

---

## 🛠️ 技术栈

### 后端框架
| 语言 | 框架 | 用途 |
|------|------|------|
| Python | FastAPI, Flask | API 服务 |
| Python | asyncio | 异步处理 |
| Go | Gin | 高性能服务 |
| Rust | Actix | 系统编程 |

### 数据处理
| 工具 | 用途 |
|------|------|
| Pandas | 数据分析 |
| NumPy | 数值计算 |
| Scikit-learn | 机器学习 |

### 交易所 API
| 交易所 | Python SDK |
|--------|------------|
| Binance | `ccxt` / `binance-connector` |
| Coinbase | `coinbase-exchange` |
| Bybit | `pybit` |

### 区块链交互
| 链 | SDK |
|----|-----|
| Solana | `solana` / `solders` |
| Ethereum | `web3.py` |
| Base | `ethers` |

### 部署
| 工具 | 用途 |
|------|------|
| Docker | 容器化 |
| AWS/GCP | 云服务器 |
| Railway/Render | 简单部署 |

---

## 🌟 著名开源项目

### 1. FreqTrade
- **语言**: Python
- **特点**: 功能完整，支持回测
- **GitHub**: freqtrade/freqtrade
- **官网**: https://www.freqtrade.io/

### 2. Jesse
- **语言**: Python
- **特点**: 专业级回测
- **官网**: https://jesse.trade/

### 3. CryptoHopper
- **类型**: SaaS
- **特点**: 无需代码

### 4. 3Commas
- **类型**: SaaS
- **特点**: 自动化交易

### 5. HaasOnline
- **类型**: SaaS
- **特点**: 高级策略

---

## 📚 学习路线

### 第一阶段：基础知识
```
Week 1-2:
□ 理解加密货币市场
□ 学习技术分析基础
□ 了解交易所 API
□ 熟悉 Python 基础
```

### 第二阶段：核心开发
```
Week 3-4:
□ 数据收集系统
□ 策略框架搭建
□ 订单管理系统
□ 回测系统开发
```

### 第三阶段：进阶
```
Week 5-6:
□ 风险管理模块
□ 机器学习策略
□ 实时交易测试
□ 监控告警系统
```

### 第四阶段：优化
```
Week 7-8:
□ 性能优化
□ 策略分散
□ 压力测试
□ 正式部署
```

---

## ⚠️ 重要警告

### 永远不要
- ❌ 用超过能承受损失的资金
- ❌ 相信"稳赚不赔"的策略
- ❌ 忽视风险管理
- ❌ 24/7 自动交易（没有监控）
- ❌ 分享私钥/API Secret

### 永远要
- ✅ 回测验证策略
- ✅ 设置止损
- ✅ 监控交易
- ✅ 定期检查策略表现
- ✅ 分散策略和资产

---

## 📖 参考资源

### 书籍
- "Advances in Financial Machine Learning" - Marcos Lopez de Prado
- "Machine Learning for Algorithmic Trading" - Stefan Jansen
- "Quantitative Trading" - Ernest Chan

### 在线课程
- Coursera: Financial Markets
- Udacity: Artificial Intelligence for Trading
- edX: Algorithmic Trading

### 社区
- Reddit: r/algotrading, r/cryptocurrency
- Discord: FreqTrade, Jesse
- Twitter: @quant_trader

---

## 🎯 后续学习计划

1. **本周**：完成基础知识学习
2. **下周**：搭建策略框架
3. **下月**：回测第一个策略
4. **下季度**：小资金实盘测试

---

**最后提醒**：
> 交易有风险，投资需谨慎。  
> 永远不要投入超过能承受损失的资金。  
> 回测表现 ≠ 实盘表现。  

---

*学习笔记创建时间：2026-02-08*
*版本：v1.0*
